# consoleprint
Python-based library for convenient handling of colored console prints
